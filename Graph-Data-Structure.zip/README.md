# Graph-Data-Structure
Java Graph Data Structure for CSE 2321: Foundations 1
Interfaces: Adjacency List, Adjacency Matrix
Classes: Bipartite, Topological Sort, Shortest Path
# Setup
* Download and extract Graph-Data-Structure.zip
* `cd Graph-Data-Structure`
# Compile
`javac shortestPath.java`
# Run
`java shortestPath graphX.txt`
