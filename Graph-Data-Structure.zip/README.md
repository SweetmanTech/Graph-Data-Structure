# Graph-Data-Structure
Java Adjacency List Data Structure for CSE 2321: Foundations 1
# Setup
* Download and extract Graph-Data-Structure.zip
* `cd Graph-Data-Structure`
# Compile
`javac Bipartite.java`
# Run
`java Bipartite graphX.txt`
